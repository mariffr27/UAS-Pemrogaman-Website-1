async function submitLogin(event) {
    event.preventDefault(); // Mencegah refresh halaman

    const formData = new FormData(event.target);
    const response = await fetch("login.class.php", {
        method: "POST",
        body: formData,
    });

    const result = await response.json();

    if (result.success) {
        alert(result.message);

        // Periksa apakah pengguna adalah admin
        if (result.isAdmin) {
            window.location.href = "./admin/dashboard-admin.php"; // Arahkan ke dashboard admin
        } else {
            window.location.href = "index.php"; // Arahkan ke halaman default
        }
    } else {
        alert(result.message);
    }
}