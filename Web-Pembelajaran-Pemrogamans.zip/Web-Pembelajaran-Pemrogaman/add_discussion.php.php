<?php
// File JSON
$file = 'forum.json';

// Mendapatkan data dari request
$data = json_decode(file_get_contents('php://input'), true);

// Validasi data
if (isset($data['id'], $data['title'], $data['author'], $data['content'])) {
    // Baca file JSON
    $currentData = json_decode(file_get_contents($file), true);

    // Tambahkan diskusi baru
    $currentData[] = $data;

    // Simpan kembali ke file JSON
    if (file_put_contents($file, json_encode($currentData, JSON_PRETTY_PRINT))) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
} else {
    echo json_encode(['success' => false]);
}
?>
