<?php
    session_start();
    $is_logged_in = isset($_SESSION['user']); // Cek apakah user login
    echo "<script>var isLoggedIn = " . json_encode($is_logged_in) . ";</script>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Forum</title>
    <link rel="stylesheet" href="assets/css/forum.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- <script src="assets/js/forum.js" defer></script> -->
</head>
<body>
    <header>
        <nav>
            <div class="main-bar">
                <img src="assets/images/logo.png" alt="logo" class="logo-web" style="max-width: 100px;">
                <button class="menu-toggle">☰</button>
                <ul class="navbar">
                    <li><a href="Index.php">Beranda</a></li>
                    <li><a href="menu-class.php">Kelas</a></li>
                    <li><a href="menu-forum.php">Forum</a></li>
                    <li><a href="menu-aboutUs.php">About Us</a></li>
                </ul>
                <?php if (isset($_SESSION['user'])): ?>
                    <div class="user-info">
                        <span>Halo, <?= htmlspecialchars($_SESSION['user']['name']); ?></span>
                        <a href="logout.php"><button class="btn-logout">Keluar</button></a>
                    </div>
                <?php else: ?>
                    <a href="menu-login.php"><button class="btn-login">Masuk</button></a>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <!-- Forum Menu -->
    <section class="forum-menu">
        <div class="container">
            <h2><i cl   ass="fas fa-comments"></i> Forum</h2>
            <ul class="forum-nav">
                <li><a href="#" onclick="loadDiscussionsFromJSON('all')"><i class="fas fa-list"></i> Semua Topik</a></li>
                <li><a href="#" onclick="loadDiscussionsFromJSON('popular')"><i class="fas fa-fire"></i> Terpopuler</a></li>
                <li><a href="#" onclick="loadDiscussions('categories')"><i class="fas fa-tags"></i> Kategori</a></li>

            </ul>
    <button onclick="openPopup()">Tambah Forum</button>

        </div>
    </section>

    <main>
        <section class="forum-section">
            <h2>📚 Daftar Diskusi</h2>
            <div id="forum-list" class="forum-list">
                <!-- Diskusi akan dimuat di sini -->
            </div>
        </section>
    </main>
    <!-- Popup Detail Forum -->
<div id="forum-popup" class="popup-overlay" style="display: none;">
    <div class="popup-content">
        <span class="close-popup" onclick="closePopup()">&times;</span>
        <div id="popup-details">
            <!-- Detail forum akan dimuat di sini -->
        </div>
        <hr>
        <div id="popup-comments">
            <h4>💬 Komentar</h4>
            <div id="comments-list">
                <!-- Daftar komentar akan dimuat di sini -->
            </div>
            <form id="add-comment-form" onsubmit="addComment(event)">
                <textarea id="comment-input" placeholder="Tulis komentar Anda..." required></textarea>
                <button type="submit" class="btn-submit">Tambahkan Komentar</button>
            </form>
        </div>
    </div>
</div>

<div class="popup-container" id="popupContainer">
        <div class="popup">
            <h2>Tambah Diskusi</h2>
            <input type="text" id="title" placeholder="Judul Diskusi">
            <input type="text" id="author" placeholder="Penulis">
            <textarea id="content" rows="4" placeholder="Konten Diskusi"></textarea>
            <button onclick="addDiscussion()">Tambah</button>
            <button onclick="closePopup()" style="background: #ccc; color: #000;">Batal</button>
        </div>
    </div>



<!-- Tambahkan link Font Awesome untuk ikon -->

    <footer>
        <div class="footer-content">
            <p>&copy; 2025 Your Learning Platform. All Rights Reserved.</p>
        </div>
    </footer>


    <!-- <script src="assets/js/forum.js"></script> -->
    <script>
        let forumData = [];

async function loadForums() {
    try {
        const response = await fetch('forum.json'); // Memuat file JSON
        const forums = await response.json();
        forumData = forums;
        renderForum();
    } catch (error) {
        console.error('Error loading forum data:', error);
    }
}

function renderForum() {
    const forumList = document.getElementById('forum-list');
    forumList.innerHTML = '';

    forumData.forEach(forum => {
        const forumItem = document.createElement('div');
        forumItem.classList.add('forum-item');
        forumItem.setAttribute('onclick', `openDiscussion('${forum.id}')`);

        forumItem.innerHTML = `
            <div class="forum-icon">
                <i class="${forum.icon}"></i>
            </div>
            <div class="forum-content">
                <h3>${forum.title}</h3>
                <p>Diskusi dimulai oleh <strong>${forum.author}</strong></p>
                <span class="forum-meta">📅 ${forum.date} | 💬 ${forum.comments} Komentar</span>
            </div>
        `;

        forumList.appendChild(forumItem);
    });
}

function openPopup() {
    document.getElementById('popupContainer').style.display = 'flex';
}

function closePopup() {
    document.getElementById('popupContainer').style.display = 'none';
    document.getElementById('forum-popup').style.display = 'none';
}

function addDiscussion() {
    const title = document.getElementById('title').value;
    const author = document.getElementById('author').value;
    const content = document.getElementById('content').value;

    if (title && author && content) {
        const newDiscussion = {
            id: `diskusi${forumData.length + 1}`,
            title: title,
            author: author,
            date: new Date().toISOString().split('T')[0],
            comments: 0,
            icon: "fas fa-comments",
            content: content
        };

        forumData.push(newDiscussion);
        renderForum();
        closePopup();
    } else {
        alert('Harap isi semua bidang.');
    }
}

function openDiscussion(discussionId) {
    const forum = forumData.find(f => f.id === discussionId);

    if (forum) {
        // Tampilkan detail forum
        const popupDetails = document.getElementById('popup-details');
        popupDetails.innerHTML = `
            <h3>${forum.title}</h3>
            <p><strong>Dimulai oleh:</strong> ${forum.author}</p>
            <p><strong>Tanggal:</strong> ${forum.date}</p>
            <p><strong>Jumlah Komentar:</strong> ${forum.comments}</p>
            <p>${forum.content}</p>
        `;

        // Tampilkan popup
        const popupOverlay = document.getElementById('forum-popup');
        popupOverlay.style.display = 'flex';

        // Simpan ID diskusi aktif untuk menambahkan komentar
        window.activeDiscussionId = discussionId;
    } else {
        alert('Diskusi tidak ditemukan.');
    }
}

document.addEventListener('DOMContentLoaded', loadForums);


    </script>
</body>
</html>
